// we are going to declare our first variable 
// let is a way to intiliaze a variable. there is three different way to do that 
// we have let , var , const 
// var is gonna apply to the entire program , let is more limited scope

// this variable is going to keep track of the order of the lights 
let order =[];

// this one is going to keep track of the order that the player actual make 
let playerOrder =[];

// this one is going to store the number of flashs that appear in the game
let flash;  // interger 

// this one so that we keep the turn we are on , kind of the round 
let turn ;

// this one is going to be a boolean , it will tell us if we actually followed the right pattern
let good;

// this one is boolean too , it will tell us if it is the computer turn or the players turn
let compTurn;

// 
let intervalId;

// this one keep track to see if the strict button has been checked or not 
let strict = false;

// this one is for the sound noise 
let noise =true;

// this one is to check if the power button has been turned on 
let on = false;

//  this one to see if the player has won or not
let win;

/* now we are going to use some constant to refer to our html */
// this one is the count display we have 
const turnCounter =document.querySelector("#turn"); // we referenced a css id. now we took the html element and put it into the turnCounter variable.

// now we can use the javascript to manipulate that element

// !!!!! now we are going to the same thing for other elements
const topLeft = document.querySelector("#topleft");
const topRight=document.querySelector("#topright");
const bottomLeft=document.querySelector("#bottomleft");
const bottomRight=document.querySelector("#bottomright");
const strictButton= document.querySelector("#strict");
const onButton= document.querySelector("#on");
const startButton=document.querySelector("#start");

// now we are going to write the code in the same way we are gonna play the game

// we start with the strict button
// we are going to add an event llistener 
// change is the event  and we are gonna pass that to the function
// this is a common way write function for listners : arrow functions 
// we can use an event listner change or click 
strictButton.addEventListener('click',(event)=>{
    // the checked option is only working because we have a check box.
if(strictButton.checked == true){
    strict = true;

}else {
    strict = false ;
}

// notice we didnt use the event we passed , but that is okay , usually we pass the event to the event listner even if we dont use it.
}) ;
onButton.addEventListener('click',(event)=>{
    if(onButton.checked==true){
       // these vairables are the ones we declared above 
        on =true;
        // now we need to initialize the counter 
        turnCounter.innerHTML="-"; 
        // innerHtml is going to put in the html file in the turn bracket whatever we specify here. and since it empty now. it will specify -.
    }else {
        on=false;
        turnCounter.innerHTML="";
        clearColor(); // this function will re-initialize the colors to default when we turn off 
        clearInterval(intervalId);

    }
});

startButton.addEventListener('click',(event)=>{
    // if the on button is true or  win is true --> then play
    if(on || win){
        play();
    }
});

// now we define the play function
// basic way to define a function 
function play(){
    // first thing thing we when play the game we need to reset the variables
    win= false;
    order=[];
    playerOrder=[];
    flash=0;
    intervalId=0;
    turn=1;
    turnCounter.innerHTML=1;
    good=true;

    // now we need to use a for loop to fill the order variable 
    // Math.floor is gonna roundup the result we get from Math.random
    // the math.random give us a number btween 0 and 1 multiply it by  4 it gives us a number btwn 0and 4 
    // when we add 1 , it gives a number btwn 1 and 4 
    for(var i=0;i< 20; i++){
        order.push(Math.floor(Math.random()*4)+1);
    }
    // we turn the computer turn and we give it the values of the order
    compTurn=true;
    // set interval is gonna run a function given a certain interval: here it will run the function gameTurn each 800 msecond
    intervalId=setInterval(gameTurn,800);

}

    // define gameTrun function

    function gameTurn(){
        on=false; // we do this because we dont want the player to be able to click when it is the computer turn

        // now if the number of flash is equal to number of turn speciifed in the count it means the computer turn is over 
        if(flash== turn){
            clearInterval(intervalId);
            compTurn=false;
            clearColor();
            on= true;  // now it is up to the player
        }
         if(compTurn){
             clearColor(); 
             // we define a function using the syntaxe js6
             // this function is going to run one single time 
             setTimeout(()=> {
                if(order[flash]==1) one(); // it means it gonna flash the green button
                if(order[flash]==2) two();   // red
                if(order[flash]==3) three(); // 
                if(order[flash]==4) four();
                flash++;

             },200); // it will flash each 200 msecond
         }
    }

    function one(){
        if(noise){
            // we could use querySelector("#clip1")
            let audio = document.getElementById("clip1"); // we refer to the audio we have in the html file 
            // now we are going to use it 
            audio.play();
        }
        noise = true;
        // here we are going to use javascript to change the css background color from dark to light green.
        topLeft.style.backgroundColor ="lightgreen"; 
    }

    function two(){
        if(noise){
            // we could use querySelector("#clip1")
            let audio = document.getElementById("clip2"); // we refer to the audio we have in the html file 
            // now we are going to use it 
            audio.play();
        }
        noise = true;
        // here we are going to use javascript to change the css background color from dark to light green.
        topRight.style.backgroundColor ="tomato"; 
    }

    function three(){
        if(noise){
            // we could use querySelector("#clip1")
            let audio = document.getElementById("clip3"); // we refer to the audio we have in the html file 
            // now we are going to use it 
            audio.play();
        }
        noise = true;
        // here we are going to use javascript to change the css background color from dark to light green.
        bottomLeft.style.backgroundColor ="yellow"; 
    }

    function four(){
        if(noise){
            // we could use querySelector("#clip1")
            let audio = document.getElementById("clip4"); // we refer to the audio we have in the html file 
            // now we are going to use it 
            audio.play();
        }
        noise = true;
        // here we are going to use javascript to change the css background color from dark to light green.
        bottomRight.style.backgroundColor ="lightskyblue"; 
    }

    // define clearColor()
    function clearColor(){

        topLeft.style.backgroundColor ="darkgreen"; 
        topRight.style.backgroundColor ="darkred"; 
        bottomLeft.style.backgroundColor ="goldenrod"; 
        bottomRight.style.backgroundColor ="darkblue"; 
    }
        function flashColor(){
            topLeft.style.backgroundColor ="lightgreen"; 
            topRight.style.backgroundColor ="tomato"; 
            bottomLeft.style.backgroundColor ="yellow"; 
            bottomRight.style.backgroundColor ="lightskyblue"; 
        }
    // now we need to add event listners so that the user can click on the button when it is on 

    // firt we add some event listners 

    topLeft.addEventListener('click',(event) =>{
        // if green is on 
        if(on){
            playerOrder.push(1);
            // this is a function to check if the player is right
           check();
            one();  // same function the computer calls 
            if(!win){
                setTimeout(() =>{
                    clearColor();
                }, 300);
            }
        }

    })

    // topRight : red

    topRight.addEventListener('click',(event) =>{
        // if green is on 
        if(on){
            playerOrder.push(2);
            // this is a function to check if the player is right
           check();
            two();  // same function the computer calls 
            if(!win){
                setTimeout(() =>{
                    clearColor();
                }, 300);
            }
        }

    })

    // bottomLeft : yellow
    bottomLeft.addEventListener('click',(event) =>{
        // if green is on 
        if(on){
            playerOrder.push(3);
            // this is a function to check if the player is right
           check();
            three();  // same function the computer calls 
            if(!win){
                setTimeout(() =>{
                    clearColor();
                }, 300);
            }
        }

    })
    
    // bottomRight : Blue

    bottomRight.addEventListener('click',(event) =>{
        // if green is on 
        if(on){
            playerOrder.push(4);
            // this is a function to check if the player is right
           check();
            four();  // same function the computer calls 
            if(!win){
                setTimeout(() =>{
                    clearColor();
                }, 300);
            }
        }

    })

    // now we define the check function 

    function check(){
        // if the player order is different from the real order then the variable good is set to false 
        if(playerOrder[playerOrder.length -1]!== order[playerOrder.length -1]) 
        good=false;

        // now if the turn is 20 , meaning the last round
        if(playerOrder.length == 20 && good){
            winGame();
        }
        // if the user gets one wrong
        if(good == false){
            flashColor();
            // first it is gonna display no 
            turnCounter.innerHTML="No!";
            // and then it is gonna display the turn number 
            setTimeout(()=>{
                turnCounter.innerHTML=turn;
                clearColor();

            // if strict mode 
            if(strict){
                play(); // it will reset the game
            }else{
                compTurn = true;
                flash =0;
                playerOrder=[];
                good=true;
                intervalId= setInterval(gameTurn,800);
            }
            },800);
            noise = false;  // we only play the noise when the player got it right
        }
            // if the player got it correct but it is not round 20
            if( turn == playerOrder.length && good && !win){
                
                turn++;
                playerOrder=[];
                compTurn = true;
                flash =0;
                turnCounter.innerHTML=turn;
                intervalId = setInterval(gameTurn,800);
            }

    }

function winGame(){
    flashColor();
    turnCounter.innerHTML="WIN !";
    on = false; // the user can play anymore because the game is finished 
    win= true;

}
